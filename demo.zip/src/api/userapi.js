export default {
    user_list: '/user/list'//查询用户列表
    ,user_del:'/user/del/'//删除用户
    ,add_user:'/user/save'//增加用户
    ,get_user:'/user/get/'//获取单个用户信息
    ,update_user:"/user/update"//更新用户信息
}